﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurent_Application.Utility
{
    public static class Utils
    {
        public static string DefaultImage = "defualtImage.jpg";
        public static string CustomerUser = "CustomerUser";
        public static string ManagerUser = "ManagerUser";
        public const string ShoppingCartCount = "CartCount";
    }
}
