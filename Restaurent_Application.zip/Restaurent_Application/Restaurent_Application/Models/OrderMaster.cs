﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurent_Application.Models
{
    public class OrderMaster
    {
        [Key]
        public int Id { get; set; }
        public string UserId { get; set; }
        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; }
        public string Name { get; set; }
        [DisplayFormat(DataFormatString ="{0:c}")]
        public DateTime OrderDate { get; set; }
        public double? OrderTotal { get; set; }
        public double? OrderTotalOrginal { get; set; }
        public DateTime PickUpDate { get; set; }
        public DateTime PickUpTime { get; set; }
        public string Status { get; set; }
        public string PaymentStatus { get; set; }
        public string Comment { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
    }
}
