﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurent_Application.Models
{
    public class Items
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }

        public string Description { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public double? Price { get; set; }

        public string Image { get; set; }

        [Display(Name = "Type Of Dish")]
        public int? CategoryId { get; set; }

        [Display(Name = "Name Of Dish")]
        public int? SubCategoryId { get; set; }

        [ForeignKey("CategoryId")]
        [Display(Name = "Type Of Dish")]

        public virtual Category Category { get; set; }

        [ForeignKey("SubCategoryId")]
        [Display(Name = "Name Of Dish")]
        public virtual SubCategory SubCategory { get; set; }
    }
}
