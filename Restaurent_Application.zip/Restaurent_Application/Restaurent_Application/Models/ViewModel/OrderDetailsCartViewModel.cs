﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurent_Application.Models.ViewModel
{
    public class OrderDetailsCartViewModel : Items
    {
        public string Nonce { get; set; }
        public List<ShoppingCart> cartList { get; set; }
        public OrderMaster orderMaster { get; set; }
        public string PaymentMethodNonce { get; internal set; }
    }
}
