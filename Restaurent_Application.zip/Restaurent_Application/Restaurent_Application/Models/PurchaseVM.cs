﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurent_Application.Models
{
    public class PurchaseVM : Items
    {
        public string Nonce { get; set; }
    }
}
