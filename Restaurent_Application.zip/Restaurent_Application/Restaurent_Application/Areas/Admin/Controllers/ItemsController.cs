﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PagedList;
using Restaurent_Application.Data;
using Restaurent_Application.Models;
using Restaurent_Application.Utility;

namespace Restaurent_Application.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ItemsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _hostingEnvironment;

        public ItemsController(ApplicationDbContext context, IWebHostEnvironment hostingEnvironment)
        {
            _context = context;
            _hostingEnvironment = hostingEnvironment;
        }

        // GET: Admin/Items
        public async Task<IActionResult> Index(int pg = 1)
        {
            var applicationDbContext = _context.Items.Include(i => i.Category).Include(i => i.SubCategory);
            const int pageSize = 2;
            if (pg < 1)
                pg = 1;
            int resCount = applicationDbContext.Count();
            var pager = new Pager(resCount, pg, pageSize);
            int resSkip = (pg - 1) * pageSize;
            var data = applicationDbContext.Skip(resSkip).Take(pager.PageSize).ToList();
            this.ViewBag.Pager = pager;
            var claimsIdentity = (ClaimsIdentity)this.User.Identity;
            var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
            if (claim != null)
            {
                var Count = _context.ShoppingCarts.Where(u => u.ApplicationUserId == claim.Value).Count();//how it is taking count
                HttpContext.Session.SetInt32(Utils.ShoppingCartCount, Count);
            }
            return View(data);
            //return View(await applicationDbContext.ToListAsync());
        }

        public async Task<IActionResult> VegItems(int id1 = 1)
        {
            var vegItems =await _context.Items.Include(i => i.Category).Include(i => i.SubCategory).Where(i => i.CategoryId == id1).ToListAsync();
            return View(vegItems);
        }

        public async Task<IActionResult> NonVegItems(int id2 = 2)
        {
            var nonVegItems =await _context.Items.Include(i => i.Category).Include(i => i.SubCategory).Where(i => i.CategoryId == id2).ToListAsync();
            return View(nonVegItems);
        }
        // GET: Admin/Items/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var items = await _context.Items
                .Include(i => i.Category)
                .Include(i => i.SubCategory)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (items == null)
            {
                return NotFound();
            }

            return View(items);
        }

        // GET: Admin/Items/Create
        public IActionResult Create()
        {
            Items items = new Items();
            ViewData["CategoryId"] = new SelectList(_context.TypeOfDish, "Id", "Name");
            ViewData["SubCategoryId"] = new SelectList(_context.NameOfDishes, "Id", "Name");
            //return View();
            return PartialView("ItemsModelPartial", items);

        }

        // POST: Admin/Items/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Description,Price,Image,CategoryId,SubCategoryId")] Items items)
        {
            if (ModelState.IsValid)
            {
                _context.Add(items);
                await _context.SaveChangesAsync();
                string webRootPath = _hostingEnvironment.WebRootPath;
                var files = HttpContext.Request.Form.Files;
                var productFromDb = await _context.Items.FindAsync(items.Id);
                string path = Path.Combine(_hostingEnvironment.WebRootPath, "images").ToLower();
                if (!Directory.Exists(path)) { Directory.CreateDirectory(path); }

                if (files.Count > 0)
                {
                    var uploads = Path.Combine(webRootPath, "images");
                    var extension = Path.GetExtension(files[0].FileName);
                    using (var fileStream = new FileStream(Path.Combine(uploads, items.Id + extension), FileMode.Create))
                    {
                        files[0].CopyTo(fileStream);
                    }
                    productFromDb.Image = @"\images\" + items.Id + extension;

                }

                else
                {
                    var uploads = Path.Combine(webRootPath, @"images\" + Utils.DefaultImage);
                    System.IO.File.Copy(uploads, webRootPath + @"images\" + items.Id + ".png");

                    productFromDb.Image = @"\images\" + items.Id + ".png";

                }
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoryId"] = new SelectList(_context.TypeOfDish, "Id", "Name", items.CategoryId);
            ViewData["SubCategoryId"] = new SelectList(_context.NameOfDishes, "Id", "Name", items.SubCategoryId);
            return View(items);
        }

        // GET: Admin/Items/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var items = await _context.Items.FindAsync(id);
            if (items == null)
            {
                return NotFound();
            }
            ViewData["CategoryId"] = new SelectList(_context.TypeOfDish, "Id", "Name", items.CategoryId);
            ViewData["SubCategoryId"] = new SelectList(_context.NameOfDishes, "Id", "Name", items.SubCategoryId);
            return View(items);
        }

        // POST: Admin/Items/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,Price,Image,CategoryId,SubCategoryId")] Items items)
        {
            if (id != items.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(items);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ItemsExists(items.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                TempData["SuccessMessage"] = "Item" + items.Name + "Saved Successfully!";
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoryId"] = new SelectList(_context.TypeOfDish, "Id", "Name", items.CategoryId);
            ViewData["SubCategoryId"] = new SelectList(_context.NameOfDishes, "Id", "Name", items.SubCategoryId);
            return View(items);
        }

        // GET: Admin/Items/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var items = await _context.Items
                .Include(i => i.Category)
                .Include(i => i.SubCategory)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (items == null)
            {
                return NotFound();
            }

            return View(items);
        }

        // POST: Admin/Items/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var items = await _context.Items.FindAsync(id);
            _context.Items.Remove(items);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ItemsExists(int id)
        {
            return _context.Items.Any(e => e.Id == id);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(string SearchString)
        {


            if (!String.IsNullOrEmpty(SearchString))
            {
                var applicationDbContext = _context.Items.Include(p => p.Category).Include(p => p.SubCategory).Where(p => p.Name.Contains(SearchString) || p.Price.ToString().Contains(SearchString));
                return View(await applicationDbContext.ToListAsync());
            }
            else
            {
                var applicationDbContext = _context.Items.Include(p => p.Category).Include(p => p.SubCategory);
                return View(await applicationDbContext.ToListAsync());
            }
            ViewBag.StrSearch = SearchString;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> FilterAsync(IFormCollection formCollection)
        {
            string result = formCollection["FilterR"].ToString();

            if (result == "Price")
            {
                var applicationDbContext = _context.Items.Include(p => p.Category).Include(p => p.SubCategory).OrderByDescending(p => p.Price);
                return View(await applicationDbContext.ToListAsync());
            }
            if (result == "BestSeller")
            {
                var applicationDbContext = _context.Items.Include(p => p.Category).Include(p => p.SubCategory).OrderBy(p => p.Price);
                return View(await applicationDbContext.ToListAsync());
            }
            return View();
        }


        // feedback
        public async Task<IActionResult> Feedback(int id)
        {
            Comments feedbackForm = new Comments();
            feedbackForm.ItemId = id;
            //  ViewBag.ProductId = id;
            return View(feedbackForm);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Feedback(Comments feedback)
        {
            var claimsIdentity = (ClaimsIdentity)this.User.Identity;
            var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
            var userId = await _context.ApplicationUsers.Where(u => u.Id == claim.Value).FirstOrDefaultAsync();
            feedback.LoginUser = userId.Id;
            feedback.Id = 0;
            feedback.FeedbackDate = DateTime.UtcNow;
            feedback.Rating = 0;
            _context.Add(feedback);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> FeedbackManager(int id)
        {
            return View(await _context.Comments.Where(p => p.ItemId.Equals(id)).ToListAsync());
        }

        //Cart Part

        public async Task<IActionResult> CartDetails(int id)
        {
            var productsFromDb = await _context.Items.Include(x => x.Category).Include(x => x.SubCategory).Where(x => x.Id == id).FirstOrDefaultAsync();
            ShoppingCart shoppingCart = new ShoppingCart()
            {
                Items = productsFromDb,
                ItemId = productsFromDb.Id
            };
            return View(shoppingCart);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CartDetails(ShoppingCart shoppingCart)// to change the count
        {
            shoppingCart.Id = 0;
            if (ModelState.IsValid)
            {
                
                var claimsIdentity = (ClaimsIdentity)this.User.Identity;
                var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
                shoppingCart.ApplicationUserId = claim.Value;
                ShoppingCart cartFromDb = await _context.ShoppingCarts.Where(x => x.ApplicationUserId == shoppingCart.ApplicationUserId
                                                                    && x.ItemId == shoppingCart.ItemId).FirstOrDefaultAsync();

                if (cartFromDb == null)
                {
                    await _context.ShoppingCarts.AddAsync(shoppingCart);
                }
                else
                {
                    cartFromDb.Count = cartFromDb.Count + shoppingCart.Count;
                }
                await _context.SaveChangesAsync();
                var count = _context.ShoppingCarts.Where(x => x.ApplicationUserId == shoppingCart.ApplicationUserId).ToList().Count();
                HttpContext.Session.SetInt32(Utils.ShoppingCartCount, count); //session
                return RedirectToAction(nameof(Index));
            }
            else
            {
                var productFromDb = await _context.Items.Include(x => x.Category).Include(x => x.SubCategory).Where(x => x.Id == shoppingCart.ItemId).FirstOrDefaultAsync();
                ShoppingCart sCart = new ShoppingCart()
                {
                    Items = productFromDb,
                    ItemId = productFromDb.Id
                };
                TempData["Message"] = "Item Added To Cart Successfull";
                return View(sCart);
            }
        }
    }
}
