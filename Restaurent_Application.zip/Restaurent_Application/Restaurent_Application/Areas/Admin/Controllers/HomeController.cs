﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Restaurent_Application.Data;
using Restaurent_Application.Models;
using Restaurent_Application.Utility;

namespace Restaurent_Application.Controllers
{
    [Area("Admin")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        //[Authorize(Roles = "ManagerUser")]
        public IActionResult Privacy()
        {
            if (User.IsInRole(Utils.CustomerUser))
            {
                return View(nameof(AcessDenied));
            }
                return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult AcessDenied()
        {
                return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(string SearchString)
        {


            if (!String.IsNullOrEmpty(SearchString))
            {
                var applicationDbContext = _context.Items.Include(p => p.Category).Include(p => p.SubCategory).Where(p => p.Name.Contains(SearchString));
                return View(await applicationDbContext.ToListAsync());
            }
            else
            {
                var applicationDbContext = _context.Items.Include(p => p.Category).Include(p => p.SubCategory);
                return View(await applicationDbContext.ToListAsync());
            }
            ViewBag.StrSearch = SearchString;
            return View();
        }
    }
}
