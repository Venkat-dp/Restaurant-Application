﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Restaurent_Application.Data;
using Restaurent_Application.Data.Migrations;
using Restaurent_Application.Models.ViewModel;
using Restaurent_Application.Services;
using Restaurent_Application.Utility;

namespace Restaurent_Application.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<CartController> _logger;
        private readonly IBraintreeService _braintreeService;
        [BindProperty]
        public OrderDetailsCartViewModel orderDetailsCartVM { get; set; } 
        public CartController(ILogger<CartController> logger, ApplicationDbContext context, IBraintreeService braintreeService)
        {
            _context = context;
            _logger = logger;
            _braintreeService = braintreeService;
        }
        public async Task<IActionResult> Index()
        {
            orderDetailsCartVM = new OrderDetailsCartViewModel()
            {
                orderMaster = new Models.OrderMaster()
            };
            orderDetailsCartVM.orderMaster.OrderTotal = 0;
            var claimsIdentity = (ClaimsIdentity)this.User.Identity;
            var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
            var cart = _context.ShoppingCarts.Where(x => x.ApplicationUserId == claim.Value);
            if(cart != null)
            {
                orderDetailsCartVM.cartList = cart.ToList();
            }
            foreach(var item in orderDetailsCartVM.cartList)
            {
                item.Items = _context.Items.FirstOrDefault(x => x.Id == item.ItemId);
                orderDetailsCartVM.orderMaster.OrderTotal = orderDetailsCartVM.orderMaster.OrderTotal + (item.Items.Price * item.Count);
            }
            orderDetailsCartVM.orderMaster.OrderTotalOrginal = orderDetailsCartVM.orderMaster.OrderTotal;
            return View(orderDetailsCartVM);
        }

        public async Task<IActionResult> Plus(int id)
        {
            var cart = await _context.ShoppingCarts.FirstOrDefaultAsync(c => c.Id == id);
            cart.Count += 1;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Minus(int id)
        {
            var cart = await _context.ShoppingCarts.FirstOrDefaultAsync(c => c.Id == id);
            if (cart.Count == 1)
            {
                _context.ShoppingCarts.Remove(cart);
                await _context.SaveChangesAsync();

                var cnt = _context.ShoppingCarts.Where(u => u.ApplicationUserId == cart.ApplicationUserId).ToList().Count;
                HttpContext.Session.SetInt32(Utils.ShoppingCartCount, cnt);
            }
            else
            {
                cart.Count -= 1;
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Remove(int id) 
        {
            var cart = await _context.ShoppingCarts.FirstOrDefaultAsync(c => c.Id == id);
             _context.ShoppingCarts.Remove(cart);
            await _context.SaveChangesAsync();

            var cnt = _context.ShoppingCarts.Where(u => u.ApplicationUserId == cart.ApplicationUserId).ToList().Count;
            HttpContext.Session.SetInt32(Utils.ShoppingCartCount, cnt);

            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Summary()
        {
            var gateway = _braintreeService.GetGateway();
            //  var clientToken = gateway.ClientToken.Generate();
            var clientToken = "fwsafcagvoavpianv";
            ViewBag.ClientToken = clientToken;

            orderDetailsCartVM = new OrderDetailsCartViewModel()
            {
                orderMaster = new Models.OrderMaster()
            };


            orderDetailsCartVM.orderMaster.OrderTotal = 0;

            var claimsIdentity = (ClaimsIdentity)User.Identity;
            var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);

            var cart = _context.ShoppingCarts.Where(c => c.ApplicationUserId == claim.Value);
            if (cart != null)
            {
                orderDetailsCartVM.cartList = cart.ToList();
            }

            foreach (var list in orderDetailsCartVM.cartList)
            {
                list.Items = await _context.Items.FirstOrDefaultAsync(x => x.Id == list.ItemId);
                orderDetailsCartVM.orderMaster.OrderTotal = (double)(orderDetailsCartVM.orderMaster.OrderTotal + (list.Items.Price * list.Count));
                list.Items.Description = list.Items.Description;
                if (list.Items.Description.Length > 100)
                {
                    list.Items.Description = list.Items.Description.Substring(0, 99) + "...";
                }
            }
            orderDetailsCartVM.orderMaster.OrderTotalOrginal = orderDetailsCartVM.orderMaster.OrderTotal;
            return View(orderDetailsCartVM);

        }

        public async Task<IActionResult> Purchase()
        {

            return View();

        }
    }
}
